import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [text, onChangeText] = React.useState('Name :');
  const [school, onChangeTextschool] = React.useState('School :');
  const [address, onChangeaddress] = React.useState('Address :');
  const [course, onChangecourse] = React.useState('Course :');
  const [email, onChangeemail] = React.useState('Email :');
  const [age, onChangeNumberage] = React.useState('Age :');
  const [contact, onChangecontact] = React.useState('Contact #');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText}
          value={text}
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeNumberage}
          value={age}
          placeholder="Age :"
          keyboardType="numeric"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeaddress}
          value={address}
          placeholder="Address :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeTextschool}
          value={school}
          placeholder="School :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangecourse}
          value={course}
          placeholder="Course :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeemail}
          value={email}
          placeholder="Email :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangecontact}
          value={contact}
          placeholder="Contact # :"
          keyboardType="numeric"
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default TextInputExample;