import React from 'react';
import {StyleSheet, TextInput,Image,View} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
 
  const [text, onChangeTextName] = React.useState('Name:');
  const [number, onChangeTextAge] = React.useState('Age:');
  const [Address, onChangeTextAddress] = React.useState('Address:');
  const [School, onChangeTextSchool] = React.useState('School:');
  const [Course, onChangeTextCourse] = React.useState('Course:');
   const [Email, onChangeTextEmail] = React.useState('Email:');
     const [Contact, onChangeTextContact] = React.useState('Contact no: ');
     const [AboutMe, onChangeTextAboutMe] = React.useState('About Me: ');
   

  return (
    <SafeAreaProvider>
      <SafeAreaView>
       <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://icon-library.com/images/icon-name/icon-name-10.jpg' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextName}
            value={text}
            placeholder="Name"
          />
        </View>

  <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://static.vecteezy.com/system/resources/previews/010/310/977/non_2x/age-icon-on-white-background-age-limit-sign-age-symbol-reliability-logo-flat-style-vector.jpg' }} style={styles.icon} />
        <TextInput
       
          style={styles.input}
          onChangeText={onChangeTextAge}
          value={number}
          placeholder="Age:"
          keyboardType="numeric"
        />  </View>

        <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://th.bing.com/th/id/OIP.bFRSXMeNFRTpPBei_ifTFQHaHa?w=188&h=188&c=7&r=0&o=5&pid=1.7' }} style={styles.icon} />
       <TextInput
          style={styles.input}
          onChangeText={onChangeTextAddress}
          value={Address}
          placeholder="Address"
        />
        </View>

       <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://static.vecteezy.com/system/resources/previews/002/206/174/original/school-building-icon-free-vector.jpg' }} style={styles.icon} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextSchool}
          value={School}
          placeholder="School"
        />
         </View>

          <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://th.bing.com/th/id/OIP.yw6CA_3yqG1Pi9BycG6y7gHaHa?w=198&h=198&c=7&r=0&o=5&pid=1.7' }} style={styles.icon} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextCourse}
          value={Course}
          placeholder="Course"
        />
          </View>

         
          <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://th.bing.com/th/id/R.0ca9cc34607aab8cb722ab67b7b5f958?rik=FF2fM%2bCW7RqwCw&riu=http%3a%2f%2fwebbiquity.com%2fwp-content%2fuploads%2f2011%2f02%2fEmail-Icon.jpg&ehk=%2fGdR90TBkvGgN6Nmd6O6tOuSydW00%2bewtbcohsgmeQo%3d&risl=&pid=ImgRaw&r=0' }} style={styles.icon} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextEmail}
          value={Email}
          placeholder="Email"
        />    </View>

         <View style={styles.inputContainer}>
    <Image source={{ uri: 'https://th.bing.com/th/id/OIP.ZGCy-6F4IjzcfqtkHnI82QHaHa?rs=1&pid=ImgDetMain' }} style={styles.icon} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextContact}
          value={Contact}
          placeholder="Contact"
        />
        </View>
        <Image source={{ uri: 'https://th.bing.com/th/id/OIP.Jm1AxgNMXCqW6JTQoi85vgHaHa?rs=1&pid=ImgDetMain' }} style={styles.icon} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextContact}
          value={AboutMe}
          placeholder="about me"
/>

      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 12,
  },
  icon: {
    width: 20,  // adjust the width and height as per your image size
    height: 20,
    marginRight: 10,  // space between image and input field
  },
  input: {
    flex: 1,
    height: 2,
    borderWidth: 1,
    padding: 10,
  },
});


export default TextInputExample;